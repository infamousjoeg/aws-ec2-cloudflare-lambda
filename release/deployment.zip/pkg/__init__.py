from .func import getEC2InstanceIPv4
from .func import setCloudflareARecord